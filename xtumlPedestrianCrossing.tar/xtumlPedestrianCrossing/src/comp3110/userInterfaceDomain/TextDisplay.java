   package comp3110.userInterfaceDomain;

/**
* The TextDisplay class provides the ability to display text to the user
*/

   public class TextDisplay {
      
   /**
   * This method displays a text message to the user
   */
      public static void show(String message) {
         System.out.println(message);
      }
   }
