// Eric McCreath 2015 GPL 

public class MessageProblem extends Exception {

}
