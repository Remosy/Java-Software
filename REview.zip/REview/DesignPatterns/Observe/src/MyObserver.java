public interface MyObserver {
    public void update(int num);
}
