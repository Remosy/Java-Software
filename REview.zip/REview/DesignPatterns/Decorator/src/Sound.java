import java.util.ArrayList;


public interface Sound {
	ArrayList<Float> obtainsamples(); // assume signed pcm
}
