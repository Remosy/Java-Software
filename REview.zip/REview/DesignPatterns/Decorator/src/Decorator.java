
public abstract class Decorator implements Beverage{
	
	public Beverage beverage;
	Decorator(Beverage b){
		
		this.beverage=b;
	}
	

}
