
public class BaseBean2 implements Beverage{

	@Override
	public String showDescription() {
		
		return "BaseBean2";
	}

	@Override
	public double showPrice() {
		
		return 20.0;
	}

}
