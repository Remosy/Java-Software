
public class BaseBean1 implements Beverage {

	@Override
	public String showDescription() {
		return "BaseBean1";
	}

	@Override
	public double showPrice() {
		return 10.0;
		
	}

}
