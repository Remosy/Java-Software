public abstract class SoundDecorator implements Sound {

	Sound parentsound;
	
	
	
	
}
