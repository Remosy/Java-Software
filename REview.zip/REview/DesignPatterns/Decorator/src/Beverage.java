
public interface Beverage {

	
	public String showDescription();
	public double showPrice();

}

