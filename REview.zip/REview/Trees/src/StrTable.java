public interface StrTable {
	String lookup(String id);
	void insert(String id, String name);
}
