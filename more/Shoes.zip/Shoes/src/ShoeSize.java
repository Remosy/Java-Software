
/* ShoeSize - Eric McCreath 2015 - GPL 
 * This class stores a persons shoe size.
 */

import java.io.*;

public class ShoeSize {
	private static final String SHOESIZEENAME = "SHOESIZE";
	public static final int SHOESIZEMAX = 15;
	public static final int SHOESIZEMIN = 3;

	static final String FILENAME = "shoesize.xml";

	private Integer shoesize;

	public ShoeSize() {
		shoesize = null;
	}

	public String show() {
		return (shoesize == null ? "" : shoesize.toString());
	}

	public boolean set(Integer v) {
		if (v == null || v >= ShoeSize.SHOESIZEMIN && v <= ShoeSize.SHOESIZEMAX) {
			shoesize = v;
			save();
			return true;
		} else {
			shoesize = null;
			return false;
		}
	}

	static ShoeSize load() {
		ShoeSize shoeSize = new ShoeSize();
		try{
			BufferedReader b_reader = new BufferedReader(new FileReader(FILENAME));
			// read in line and test if null
			String line;

			while((line = b_reader.readLine()) != null){
				String[] dataline  = line.split(",");
				shoeSize.shoesize = Integer.parseInt(dataline[1]);
			}
			b_reader.close();
		}
		catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		}

		return shoeSize;
	}

	void save() {
		// add code here that will save shoe size into a file called "FILENAME"
		try {
			FileWriter F_W = new FileWriter(FILENAME);
			BufferedWriter B_W = new BufferedWriter(F_W);
			String line = SHOESIZEENAME + "," + show();
			B_W.write(line);
			B_W.close();
		}catch (IOException e) {
			e.printStackTrace();
		}


	}
}
