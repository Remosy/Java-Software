public class Advertisement {
    String company = "";
    int time = 0;
    int earn = 0;

    Advertisement(String company, int time, int earn){
        this.company = company;
        this.time = time;
        this.earn = earn;

    }
}
