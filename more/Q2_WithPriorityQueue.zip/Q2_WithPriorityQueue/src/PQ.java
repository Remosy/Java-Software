import java.util.ArrayList;

public class PQ{

    ArrayList<Song> items;

    PQ(){
        items = new ArrayList<Song>();
    }

    String getLongest(){
        return items.get(0).title;
    }

    int peak(int key){
        return (int) Math.ceil((key-1)/2);
    }

    void swap(int old_key, int new_key){
        Song song_old = items.get(old_key);
        items.set(old_key,items.get(new_key));
        items.set(new_key,song_old);
    }

    void addKeyWithObj(int key, Song song){
        if(song.time<items.get(key).time)return;

        while(key > 0 && items.get(peak(key)).time < items.get(key).time){
            swap(key,peak(key));
            key = peak(key);
        }
    }

    void insert(Song song){
        items.add(song);
        int loc = items.size()-1;
        addKeyWithObj(loc,song);
    }

    int getSize(){
        return items.size();
    }


}
