public class Song {
    String title = "";
    String band = "";
    int time = 0;

    Song(String name, String band, int time){
        this.title = name;
        this.band = band;
        this.time = time;
    }
}
