public class Test {

    public void testLongestName() {
        boolean p1 = false;
        PlayList playlist = new BasicPlayList();
        playlist.addSong("Vertigo","U2",210);
        playlist.addSong("Bad","Michael Jackson",230);
        playlist.addAdvertisment("AGL",30,320);
        playlist.addAdvertisment("Holden",20,210);
        playlist.addSong("Little Lamb","Mary",210);
        if(playlist.longestSong().equals("Bad"))
            p1 = true;
       // assertTrue("Expect: 'Bad'; But got"+playlist.longestSong(),p1);


    }


    public void testAdTime() {
        boolean p1 = false;
        PlayList playlist = new BasicPlayList();
        playlist.addSong("Vertigo","U2",210);
        playlist.addSong("Bad","Michael Jackson",230);
        playlist.addAdvertisment("AGL",30,320);
        playlist.addAdvertisment("Holden",20,210);
        playlist.addSong("Little Lamb","Mary",210);
        if(playlist.tooManyAds() == false)
            p1 = true;
       // assertTrue("Expect: 'false'; But got 'true'",p1);


    }

}
