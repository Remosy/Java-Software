import java.util.ArrayList;

public class BasicPlayList implements PlayList {
	PQ songs = new PQ();
	int counter = 0;
	int adv_time = 0;
	ArrayList<Integer> timelist = new ArrayList<Integer>();
	ArrayList<Advertisement> advertisements = new ArrayList<Advertisement>();
	@Override
	public void addSong(String name, String band, int time) {
		Song song = new Song(name,band,time);
		songs.insert(song);
		//Count Time
		counter+=song.time;
		if(counter>=3600){
			counter -= 3600;
			adv_time = 0;
		}
	}

	@Override
	public void addAdvertisment(String company, int time, int earn) {
		Advertisement advertisement = new Advertisement(company,time,earn);
		advertisements.add(advertisement);
		//Count Time
		adv_time+=advertisement.time;
		counter+=advertisement.time;
		if(counter>=3600){
			counter -= 3600;
			timelist.add(adv_time-counter); // Calculate adv per hour
			adv_time = counter;
		}
	}

	@Override
	public String longestSong() {
		return songs.getLongest();
	}

	@Override
	public boolean tooManyAds() {
		boolean is_tooManyAds = false;
		int bound = 12*60;
		for(Integer t : timelist){
			if(t > bound){
				is_tooManyAds = true;
				break;
			}
		}
		return is_tooManyAds;
	}

}
