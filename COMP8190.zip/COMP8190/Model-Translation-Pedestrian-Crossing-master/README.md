# Model-Translation-Pedestrian-Crossing
Model Translation of an XTUML Pedestrian Crossing System Model. Performed as part of COMP8190-Model-Driven Software Development at The Australian National University.
