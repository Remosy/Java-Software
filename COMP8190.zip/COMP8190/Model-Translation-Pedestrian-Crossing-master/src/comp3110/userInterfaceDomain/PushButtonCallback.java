package comp3110.userInterfaceDomain;

public interface PushButtonCallback {
    public void buttonPressed();
}
    

